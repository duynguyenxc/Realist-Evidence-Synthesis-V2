# What is in this folder

Every file here is an attachment to the covering email.

## Read in this order

| File | What it is |
|---|---|
| `handover/0_REQUIREMENTS_MATRIX.md` | **Read first.** Your email, clause by clause, each with a status and the file that backs it |
| `handover/1_WHAT_WE_BUILT.md` | Output 1 — the existing pipeline: inputs, outputs, architecture, prompts, evaluation |
| `handover/2_WHAT_THE_NEW_TOPIC_NEEDS.md` | Output 2 — what the new topic needs, with a step-by-step plan |
| `handover/6_PROGRESS_REPORT.md` | Output 6 — completed, limitations, next steps |
| `handover/README.md` | A short tour of the package |
| `handover/pipeline.svg` | The six stages, and the five points where the system stops and asks a person |
| `reports/SEARCH_REPORT.md` | The search, reported well enough to repeat: queries, coverage dates, deduplication |
| `reports/EVIDENCE_MAP.md` | What the 1,863 records are *about*, coded against Pekrun and Gross. **Not** what works |
| `reports/ACQUISITION_REPORT.md` | How many full texts we hold, why the rest could not be fetched, what that constrains |
| `reports/CATALOGUE_OVERLAP.md` | What four further catalogues add — the measured answer to "is the search broad enough" |
| `reports/SOURCE_AUDIT.md` | How the open scholarly infrastructure failed when automated against, and how quietly |
| `reports/COST_MODEL.md` | What each remaining stage would cost, from the real prompts and prices |
| `pipeline-and-ai-record/INSTRUCTIONS_TO_AI.md` | The standing instructions the AI is given at the start of every session — the project's rules, constraints and current state |
| `pipeline-and-ai-record/DECISION_LOG.md` | Every methodological decision, with its reasoning and what would reverse it |
| `pipeline-and-ai-record/SESSION_LOG.md` | The full development record, session by session: what was tried, what was found, what was wrong and had to be corrected |
| `pipeline-and-ai-record/ARCHITECTURE.md` | How the pipeline is put together |
| `pipeline-and-ai-record/protocol_emotion.yaml` | The review protocol for the new topic: questions, eligibility criteria, search strategy. **A draft — it has not been reviewed by anyone** |
| `pipeline-and-ai-record/coding_frame.yaml` | The theory-grounded dictionary behind the evidence map, with every revision to it recorded and justified |
| `pipeline-and-ai-record/prompts/` | The 10 agent prompts, verbatim — one file per stage |
| `reference-docs/VERIFICATION_PROTOCOL.md` | Why these are the right metrics, with citations, and an honest list of what is still missing |
| `reference-docs/MACHINE_VS_HUMAN.md` | The system's output against two human coders — the authoritative record of the comparison, including the corrections |
| `reference-docs/OUTPUT_AND_VERIFICATION.md` | What the pipeline outputs and how each is checked |
| `reference-docs/SYSTEM_AND_ALGORITHMS.md` | The algorithms, stage by stage |
| `benchmark-outputs/Knowledge_Graph_Report.html` | The Richmond knowledge graph — entities, relations and communities |
| `benchmark-outputs/MASTER_VERIFICATION_REPORT.md` | The verification report: every metric, how it was computed, and its confidence interval |
| `benchmark-outputs/raw_export/` | The benchmark database exported whole — 37 files, CSV and JSON, nothing summarised. Every figure in this package resolves to a row in here |
| `AERA_2027_paper_as_accepted.docx` | The conference paper **exactly as accepted**. Its figures have since been superseded — see the note in the covering email |
| `RICHMOND_RESULTS.html` | **Open this in a browser.** The whole benchmark review on one self-contained page: our conclusions beside Richmond's, the verification matrix, and every configuration, searchable |

## How these were produced

The six files in `handover/` are written documents. The six in `reports/` are **generated from the data by scripts**, so they cannot drift from what the pipeline holds: regenerate them and the numbers follow the database, not a memory of it. This folder is built by `scripts/make_submission.py`, which is also what built this folder.

`RICHMOND_RESULTS.html` is an export of the benchmark review's database made in October and deliberately never regenerated: it is the only surviving record of 28 human review decisions that a later schema change could not carry, so it is preserved rather than rebuilt.

## The figures in one place

| | |
|---|---|
| Candidate records | 1,863 |
| Full texts held | 662 |
| Ingested into the review database | 662 (623 with usable full text) |
| Indexed text units | 8,357 |
| Review checkpoints countersigned | 21 of 21, none disputed |
| Added catalogues returned | 590 records |
| Of those, new **and** on topic | 67 (3.6% of the corpus) |
| Cost of everything so far | $0 |

## Checking the data yourself

`data/` holds the corpus as spreadsheets, a link to the PDFs, and `DATA_QUALITY.md` — the checks a sceptical reader would run: missing fields, duplicates, impossible years, PDFs too small to be papers, text extractions too short to be useful, and whether each PDF actually contains the paper its metadata claims. Sort the `ingested_*_with_text_length.csv` file by `text_chars` ascending to find the weakest records in about ten seconds.

